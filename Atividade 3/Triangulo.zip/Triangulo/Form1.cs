﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            ladoA = 0;
            ladoB = 0;
            ladoC = 0;

            txtA.Clear();
            txtB.Clear();
            txtC.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtA.Text, out ladoA))
            {
                MessageBox.Show("Valor inválido para o lado A");
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtB.Text, out ladoB))
            {
                MessageBox.Show("Valor inválido para o lado B");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtC.Text, out ladoC))
            {
                MessageBox.Show("Valor inválido para o lado C");
                txtC.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ladoA < (ladoB + ladoC)) && (ladoA > Math.Abs(ladoB - ladoC)) &&
               (ladoB < (ladoA + ladoC)) && (ladoB > Math.Abs(ladoA - ladoC)) &&
               (ladoC < (ladoA + ladoB)) && (ladoC > Math.Abs(ladoA - ladoB)))
            {
                if(ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if(ladoA == ladoB || ladoB == ladoC || ladoA == ladoC)
                {
                    MessageBox.Show("Triângulo Isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os lados não formam um triângulo");
            }
        }
    }
}
